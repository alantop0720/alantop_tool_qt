#define _MSC_EXTENSIONS 
#define _MSC_VER 1929
#define _MSC_FULL_VER 192930146
#define _MSC_BUILD 0
#define _WIN32 
#define _M_IX86 600
#define _M_IX86_FP 2
#define _CPPRTTI 
#define _MT 
#define _DLL 
